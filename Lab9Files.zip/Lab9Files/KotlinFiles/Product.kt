package com.example.ecommapp

data class Product(
    val name:String = "",
    val price: Double = 0.0,
    val stock: Int = 0,
    val imageUrl: String = ""

)

