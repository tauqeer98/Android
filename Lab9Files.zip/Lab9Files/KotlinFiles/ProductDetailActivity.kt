package com.example.ecommapp

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.squareup.picasso.Picasso

class ProductDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_product_detail)
       /* ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }*/
        val name = intent.getStringExtra("name")
        val price = intent.getDoubleExtra("price", 0.0)
        val stock = intent.getIntExtra("stock", 0)
        val imageUrl = intent.getStringExtra("imageUrl")
        val detailName = findViewById<TextView>(R.id.detailName)
        val detailPrice = findViewById<TextView>(R.id.detailPrice)
        val detailStock = findViewById<TextView>(R.id.detailStock)
        val detailImage = findViewById<ImageView>(R.id.detailImage)
        detailName.text = name
        detailPrice.text = "Price: $$price"
        detailStock.text = "Stock: $stock"

        // Load the image from URL using Picasso
        Picasso.get()
            .load(imageUrl) // The URL of the image
            .placeholder(R.drawable.ic_launcher_background) // Optional: Placeholder image while loading
            .error(R.drawable.ic_launcher_foreground) // Optional: Error image in case of a failure
            .into(detailImage) // The ImageView to load the image into


    }
}
