package com.example.ecommapp

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ecommapp.databinding.ItemProductBinding
import com.squareup.picasso.Picasso

class ProductAdapter(private val productList: List<Product>) :
    RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    inner class ProductViewHolder(val binding: ItemProductBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val binding = ItemProductBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ProductViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]
        with(holder.binding) {
            productName.text = product.name
            productPrice.text = "$${product.price}"
            Picasso.get()
                .load(product.imageUrl) // The URL of the image
                .placeholder(R.drawable.ic_launcher_background) // Optional: Placeholder image while loading
                .resize(100,100)
                .centerCrop()
                .error(R.drawable.ic_launcher_foreground) // Optional: Error image in case of a failure
                .into(productImage) // The ImageView to load the image into



            Log.i("UOW", product.name)
            Log.i("UOW", "Price "+product.price)
            Log.i("UOW", product.imageUrl)
            root.setOnClickListener {
                val intent = Intent(root.context, ProductDetailActivity::class.java).apply {
                    putExtra("name", product.name)
                    putExtra("price", product.price)
                    putExtra("stock", product.stock)
                    putExtra("imageUrl", product.imageUrl)
                }
                root.context.startActivity(intent)
            }
        }
    }

    override fun getItemCount() = productList.size
}
